# Xuecheng 可实施性审查

日期：2026-10-09。代码基线：`8dd2749e0afee9191dee509f3b9f5427fc861329`。

本次只读检查 Native UI、Domain、Application、Repository、测试源码和 Core V2 提案，不修改业务代码、不提交 Git。以下代码路径均相对于 `XuechengNative/XuechengNative/`。本报告的规则反例来自静态推演，不是已经运行的 XCTest 结果。

## 1. 结论

**Accept with Revisions：值得继续做窄领域 MVP，但当前不能认定为已运行的学习系统。**

现状是“可复用的原生展示层 + 独立的学习领域原型”。最合理的下一步不是扩大能力图、继续美化或接入 LLM，而是修复少数可达性与状态规则问题，接通一条 Python Lists 的真实用户作答链路。

需要区分三个验收目标：

1. 原生体验 RC：界面、导航、输入、设备运行。已有基础；本轮没有复核真实设备或 CI。
2. 学习闭环 MVP：作答确实产生 Attempt、Evidence、状态和下一步。当前 UI 尚未接通。
3. 长期学习伙伴：跨启动保存、可信评估、复习、用户控制和真实学习收益。尚不能据当前原型宣称完成。

## 2. 方法与来源

采用 [HKUSTDial/Supervisor-Skills 的 idea-evaluator](https://github.com/HKUSTDial/Supervisor-Skills/tree/main/skills/idea-evaluator) 的缺陷优先、资源匹配、五维评价与第一性原理检查方法。该技能以科研方案为主要对象，本报告将其适配为工程可行性审查，不把论文创新评分当作产品验收。技能标注 CC-BY-4.0；这里保留来源归属，报告为独立分析。

已安装到 `C:/Users/Alex/.codex/skills/idea-evaluator`，没有安装无关写作技能。

## 3. 第一印象：产品价值与新颖性

“基于表现证据更新状态，再推荐下一步”是合理方向，但不是新的学习理论。Knowledge Tracing 已研究依据学习表现追踪知识并选择练习；学程的差异应落在中文原生体验、证据可解释性、用户控制和长期连续性，不能仅凭模型名称宣布理论创新。

相关原始来源：

- Corbett & Anderson, 1994, [Knowledge tracing](https://link.springer.com/article/10.1007/BF01099821)：程序技能状态追踪及练习选择。学程当前采用确定性规则，不是贝叶斯估计。
- VanLehn, 2011, [The Relative Effectiveness of Human Tutoring, Intelligent Tutoring Systems, and Other Tutoring Systems](https://doi.org/10.1080/00461520.2011.611369)：提醒我们应测量辅导交互与学习结果，而不只是完成页面。不能把其他系统的效果移植为学程的效果。
- Chi & Wylie, 2014, [ICAP Framework](https://doi.org/10.1080/00461520.2014.965823)：认知参与方式和学习结果的框架。它不等同于 Recall / Explain / Apply / Transfer，不能机械对应或作为当前阈值的验证。

本次不是系统文献综述；尚无学程用户实验、留存或迁移测试数据。

## 4. 两个首要阻塞类别

### A. 产品闭环尚未接入（重大，可修复）

- `Screens/TodayView.swift:36` 的 Next Step 读取 `PreviewFixtures.nextStep`。
- `Screens/StudySessionView.swift:19` 使用静态任务，`advance()` 在第 107 行清空答案；没有提交 Coordinator。
- `Screens/SessionResultView.swift:22` 起读取静态结果。
- `App/AppRootView.swift` 没有共享学习 Runtime；`Components/XuechengNavigation.swift` 只完成页面跳转，没有传递真实提交结果。

因此用户完成现有页面操作，不等于完成了领域链路。修复方式：App 单次创建 Runtime，持有 Repository 和 Coordinator；View 提交输入并读取结果，不能生成证据或裁定状态。

### B. 学习规则与任务目录不能保证正确推进（重大，可修复）

| 位置 | 代码事实 / 静态反例 | 最小建议 |
|---|---|---|
| `Domain/Policies/LearningPolicies.swift` + `Data/Mock/PythonListsFixture.swift` | stable 要求三个不同任务的独立成功；basics 有三题，但 traversal、comprehension 各一题。traversal 无法 stable，comprehension 因先修条件永远不能推荐 | 对每个允许解锁后继的能力补足有效验证任务；或先明确 MVP 只覆盖 basics。不要为了演示随意降低阈值 |
| `SkillStateAggregator.aggregate` | stable 时只计 `previous.updatedAt` 后的新失败。逐次提交一个错误会逐次推进 updatedAt，每次 newFailures 都只有一条，连续错误仍无法降级 | 定义稳定后失败观察窗口/累计策略；先补“逐次提交多次错误”的回归测试，再定最小规则修复 |
| `NextStepSelectionPolicy.candidate` | 先过滤全部 stable，再给 reviewDue 排序；stable 能力即使到期也进不了复习候选 | 把到期复习资格与新能力推进资格分开；保留唯一选择入口 |

这些不是新框架需求，不需要重写 Repository 或引入 BKT。

## 5. 其他边界与债务

- **测量有效性**：`EvidencePolicy` 是固定答案字符串比对，适合受限输出题，不足以验证开放解释、代码质量或迁移。Explain / Transfer 被标为低可信 proposal 并排除聚合，这是合理保守边界。confidence=1 代表比对结果确定，不代表能力已被百分百证明。
- **题目标签**：回答 `sum([2,4,6])` 的结果不能充分证明会编写遍历逻辑。应缩小能力声明或补真正对应能力的题目。
- **提交入口**：Coordinator 校验目标包含任务，但没有重新检查先修条件；如果正式流程要求只能做当前授权任务，应在 Application 检查，而不是依赖 UI 隐藏入口。
- **结果溯源**：`StudySubmission` 没有 previous SkillState 或状态变化原因。Result 要展示真实前后变化，需要由 Application 提供提交快照，不能由 View 推测。
- **重复提交**：幂等避免重复 Evidence 已有实现，但重复提交返回当前状态而非最初提交快照；以后展示历史结果须明确这两个语义。
- **恢复能力**：InMemory Repository 重启即丢。足够做单次运行闭环，不足以承诺长期成长记录。正式长期试用前，需要在 Repository 边界增加可测试的本地持久化和恢复；本轮不实施。
- **规则审计**：Evidence 有 task version，但没有聚合策略版本；未来调整规则需可解释重算。当前不必扩成复杂事件平台。
- **权限强度**：单写入者已有组织结构，但 Repository 写方法仍可被同模块调用；“Conversation 不升级状态”的现有测试只是检查未写入时为空，不能证明所有调用路径都不可写。
- **规格状态**：`docs/xuecheng-core-v2.md` 仍标记 Proposal。实现前应冻结“本轮采用的规则子集”，避免把研究建议全部默认为产品契约。

## 6. 生命周期、资源与五维评价

项目阶段：工程原型验证，不是产品规模化阶段。优势是 SwiftUI、Domain 分离和确定性窄领域可控；缺口是接线、反例测试和学习效果证据。团队人数、可投入时间、真实用户来源尚未核实。

以下从中性 5/10 出发评价当前方案相对于静态 UI 原型的预期工程收益，不是实测成绩：

| 维度 | 暂定 | 依据与待验证项 |
|---|---:|---|
| Higher：学习效果 | 5 | 有证据导向假设，但无前后测或延迟验证，不能加分 |
| Faster：达到下一步的效率 | 5 | 单一建议减少选择可能有效；当前静态 UI 无行为数据 |
| Stronger：状态可靠性 | 6 | 独立 Policy、排除不可信开放评分、幂等存储是优势；规则反例阻止更高评分 |
| Cheaper：验证成本 | 6 | 固定题与确定性评估不依赖模型调用；内容制作与维护成本未知 |
| Broader：适用范围 | 4 | 当前仅五道 Python 输出题；无法据此泛化到复杂编程或其他学科 |

第一性原理：系统应减少用户“不知道下一步”的不确定性，而不是最大化学习页面数量。

最大的隐含问题：能正确更新软件状态，不代表该状态测量了真实能力。

技术周期判断：未来 LLM 能降低练习生成成本，但不会自动解决评分可信度；目前不是引入 BKT 的时机。

最重要的问题：能否让一个真实用户完成任务后，理解系统为什么建议下一步，并在隔天无提示题中表现出相应能力？

## 7. 最省成本的实施顺序

### P0：冻结规则与补反例测试

先明确 basics 是此次完整闭环范围，后继能力不做虚假可达承诺。新增顺序失败、stable review、任务覆盖可达性和提交权限测试。若扩大到三个能力，应补足目录而不是降低标准。

验收：真实 macOS XCTest 执行新测试；检查套件、数量、失败数与 xcresult。当前源码存在 13 个测试方法，本轮没有执行，也没有重新核验历史 CI 日志。

### P1：只接 Today → Study → Result → Today

App 初始化一个 Runtime；Today 读取 Official NextStep；用户输入、提示与重试进入真实 Attempt；Coordinator 生成并保存 Evidence、聚合状态、选择唯一下一步；Result 读取提交快照；返回 Today 刷新同一仓库。

保留当前 NavigationStack 和视觉组件，不扩 Path / Companion，不接后端或 LLM。

验收：实际答案可查；重复点击不重复计证据；错误答案不算成功；结果与 Repository 一致；Runtime 页面不引用 PreviewFixtures。

### P2：设备可用性与持续性

先在 macOS Simulator 真正运行和测试，再真机验证键盘、返回、快速点击、中断恢复。若只发布 InMemory RC，明确重启丢失；进入持续试用前完成最小本地保存与恢复验证。

### P3：学习有效性小试验

使用没见过的平行题做前测、即时后测与延迟无提示验证；人工核对评分及推荐原因，记录误判和用户困难。小样本只能用于发现问题，不足以宣称普遍学习收益。

## 8. 资源与工作量估算

假设一名熟悉当前 Swift 工程的开发者、有可用 macOS/Xcode、范围保持固定题：规则/反例测试约 1–2 人日；首条 UI 接线约 2–4 人日；集成与设备 QA 约 1–2 人日。合计约 4–8 人日，不含签名排队、用户实验、长期持久化、后端及 LLM。

这是基于源码复杂度的粗估，不是交付承诺。计算资源不是主要瓶颈；评估契约、正确性测试、任务覆盖和真实设备验证才是。

## 9. 最终建议

优先三个动作：

1. 修复/界定规则与题目目录冲突，用顺序反例测试锁定行为。
2. 建立单一 Runtime，打通 basics 的真实作答与真实结果，保持现有 UI 架构。
3. 取得当前 commit 的真实 XCTest 和设备闭环证据，再决定持久化与小规模学习验证。

不建议此时重写 UI、增加学科、接复杂 Agent、引入 BKT，或把“能编译”写成“学习系统已验证”。

本轮新增文件只有本审查报告；技能安装发生在用户级 skills 目录。不修改 React、SwiftUI、Domain、API 或凭证，不提交或 push。

## 10. 后续执行记录：回归测试准备

用户确认继续后，新增四项 XCTest 规格，放在已有 `LearningDomainTests.swift` 中，不新增 target、不修改 scheme。旧有十三项测试保留；测试 helper 新增默认时间参数，旧调用行为不变。

| 测试 | 验证内容 | 运行前静态预期，不是测试结果 |
|---|---|---|
| `testSequentialFailuresAfterStableBecomeWeak` | 通过真实 Coordinator 先达到 stable，再分两次提交不同时间的错误；一次不降级，两次降为 weak | 当前逻辑第二次仍 stable，预计失败 |
| `testDueReviewOfStableCapabilityPrecedesNewCapability` | 已 stable 且已完成题目的能力到期后仍可复习，优先于新能力 | 当前返回 traversal，预计失败 |
| `testStableCapabilityWithoutDueReviewDoesNotBlockNextCapability` | 未到期时仍正常推荐后继，防止修复后一直重复旧能力 | 当前预期通过，作为保护测试 |
| `testEveryGoalCapabilityHasEnoughTasksToReachStable` | 每个目标能力在全部目录题独立答对后，真实聚合器能得出 stable | traversal、comprehension 预计失败 |

本次环境检查未找到 `swift` / `xcodebuild`，WSL 没有列出可用发行版。遵循测试驱动技能，尚未取得真实失败证据，因此暂不修改生产规则或任务目录。没有声称 17 项测试执行或通过。

macOS 下一步：取得此测试文件后，打开现有工程，选择 `XuechengNative` scheme 和已安装的 iPhone Simulator，执行 Product → Test（Command-U）。在 Test navigator / Report navigator 中保留上述四项测试的实际结果；也保留全套测试报告。先排除编译错误，再确认断言失败是否对应上述反例。

待真实失败确认后，最小修复顺序：stable 到期复习资格 → 连续失败观察语义 → 任务目录可达性。连续失败后的恢复标准、跨天有效期仍需明确契约，不借修 bug 擅自引入复杂评分或永久降级。测试预期失败的 checkpoint 不应被标成发布候选。

当前没有提交或 push。UI / Domain / Repository / Fixture / CI 均保持原状。
