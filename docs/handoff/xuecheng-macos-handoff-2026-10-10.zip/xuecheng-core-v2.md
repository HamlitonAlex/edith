# 学程核心模型 V2（Proposal）

> 状态：研究提案，尚未批准为实现规范。本文不改变现有 API、数据库、业务逻辑或 SwiftUI 页面。第三方项目仅用于机制研究，不复制代码、课程、提示词或文档内容。

## 1. Xuecheng 是什么

学程是长期学习成长伙伴：把用户的方向转成可走的能力路径，陪用户通过学习与练习产生可观察证据，再基于证据决定下一步和复习时机。产品承诺是“知道现在最值得做什么，并能看清为什么”。

### 不是什么

- 不是课程目录、打卡/时长统计器、日历或普通聊天机器人的拼接。
- 不是把 AI 的判断直接当作用户事实或能力认证。
- 不是把阅读、聊天、完成课程、用户自评等同于掌握。
- 不是要求每个目标都先生成庞大、不可修改的完整大纲。

## 2. Core User / Problem / Promise

核心用户是有持续学习目标、但难以判断起点、优先顺序和真实进展的自学者。问题不只是“内容太多”，还包括：不知道先补什么、难以发现能力边界、学习记录留在长对话里、过一阵子无法准确续上。

承诺：以用户确认的方向为约束，以能力和前置关系形成可调整的路线，以练习证据而非内容消费描述进展，并始终给出一个可开始、可推迟或可更改的下一步。

## 3. Core Learning Loop

```text
用户确认 Direction / Goal
  → 选定相关 Capability 与 prerequisites
  → 读取当前证据、弱点、复习和时间约束
  → Next Step Engine 选出唯一官方行动
  → Study Session：retrieve / teach / practice / verify
  → 追加 Learning Evidence（不覆盖历史）
  → Evidence Aggregator 更新 Skill State / weakness / review
  → Next Step Engine 再选唯一下一步
```

| 环节 | 输入 | 处理与输出 | 用户动作 | AI 权限 |
|---|---|---|---|---|
| Direction / Goal | 用户叙述、期限、使用场景 | 经用户确认的目标与优先级 | 确认、编辑、暂停 | 澄清和提议，不确立正式目标 |
| Capability 路径 | 目标、能力目录、先修关系 | 一小段可达、相关的能力子图 | 接受或调整路线 | 建议图变化；发布版本需明确确认/受控审核 |
| Next Step | State、Evidence、Review、Schedule、时间 | 唯一 current 候选和可解释原因 | 开始、稍后、替换/拒绝 | 生成候选和自然语言，不写 official state |
| Session | 一个目标、基线和学习约束 | 讲解/练习/验证过程 | 作答、求助、停止 | 引导和评分提案；不得自行宣告掌握 |
| Evidence / State | 用户作答、任务契约、评分来源 | 追加证据，由确定性聚合器更新状态 | 可查看、纠正事实性错误 | 记录可观察摘要，不能伪造独立性或评分可信度 |
| Review | 上次真实检索结果、间隔 | 新的到期日期和复习候选 | 完成、推迟 | 提议复习任务，不等于降级 Skill State |

## 4. Domain Model 与 Authority

### 4.1 对象关系

```text
Learner
├─ Direction (长期方向，可宽泛、可调整)
│  └─ Goal (用户确认的结果/里程碑，可关联多个 Capability)
├─ Learner Preference / Memory (伙伴上下文，不是能力事实)
├─ Capability Graph (领域能力目录与先修 DAG，带版本)
│  └─ Capability State (用户 × Capability × Graph Version)
│      ├─ Evidence (不可变观察记录)
│      ├─ Weakness (由多条证据支持的未解决困难)
│      └─ Review (复习调度记录)
├─ Study Session (一次学习执行过程)
│  ├─ Practice Task / Attempt
│  └─ Daily Log (用户确认的日记；不是默认证据)
├─ Next Step (单一官方行动，引用来源对象)
└─ Schedule (用户确认的时间承诺；AI 建议仍是 proposal)
```

### 4.2 Source of Truth

| 事实 | 唯一权威来源 / 写入者 | 其他模块允许做什么 |
|---|---|---|
| 长期方向、正式 Goal | 用户确认的 Goal Service/Repository | AI 提议；Memory 只可注明来源 |
| 能力定义、前置关系 | 版本化 Capability Catalog/Graph | AI 给出变更草案；不可静默改变已用版本 |
| 原始学习观察 | append-only Evidence Store | Session 提交观察；聊天正文不自动成为证据 |
| Skill State / confidence | Evidence Aggregator / Mastery Engine | UI 读取；AI 仅给评分建议及理由 |
| weakness | Evidence Aggregator（关联证据、待验证关闭条件） | Tutor 提议诊断，不因一次模糊错误写 confirmed weakness |
| Review due | Review Scheduler | Next Step Engine 消费；复习失败生成证据，不直接删除历史状态 |
| 唯一 current Next Step | Next Step Engine | Planner、Memory、Schedule 等只提交 candidate |
| 正式日程 | 用户确认后的 Schedule Repository | AI 可产生待确认建议 |
| 用户对话/偏好 Memory | Memory Service + 用户确认 | 可用于个性化，不可升级 Skill State 或覆盖 Goal |
| Daily Log | 用户确认的日志 | AI 先生成草稿；日志不等于验证过的学习证据 |
| Study Session | Session Service | Tutor 推进阶段；完成态不能自动推断能力掌握 |

## 5. Capability Graph

### 5.1 为什么新增 Capability

Goal 表达“我想达到什么结果”；Capability 表达“为了达到它，学习者需要能做什么”；课程/章节表达“内容如何编排”。三者不能互相替代。Capability 让目标、练习、证据和下一步拥有稳定关联点，也让同一能力服务多个目标。它不是一份课程目录，也不应被渲染成纯装饰的知识图谱。

### 5.2 建议最小数据形状

```text
CapabilityDefinition {
  id, title, domain, description,
  prerequisites: [capability_id], children: [capability_id],
  graph_version, provenance, active
}

CapabilityState {
  learner_id, capability_id, graph_version,
  mastery_state: unknown | learning | weak | stable,
  mastery_confidence: low | medium | high (或内部校准数值),
  evidence_count, last_evidence_at, last_positive_at, last_negative_at,
  review_state: not_due | due | overdue,
  open_weakness_ids
}

GoalCapabilityLink {
  goal_id, capability_id, relevance, target_evidence_level,
  rationale, order_hint, source, status
}
```

`prerequisites` 应视作权威 DAG 边，`children` 是可由图反向查询的导航视图，避免双写不一致。定义变更必须新建版本并保留旧 Evidence 的原始图版本；被拆分/合并的节点需要显式映射或标为不可比，不能默默把旧分数搬过去。

### 5.3 示例：成为 AI 应用开发者

```text
Goal: 能独立构建并上线一个有真实用户价值的 AI 应用
├─ Programming foundations
│  ├─ Python fundamentals
│  ├─ data structures
│  └─ Git / debugging
├─ AI application
│  ├─ LLM basics
│  ├─ prompt & evaluation
│  ├─ API integration
│  └─ retrieval / RAG
└─ Practice capability
   ├─ scoped implementation task
   ├─ integration & testing
   └─ deploy, observe, iterate
```

图只表示需要的能力及依赖，并非固定课程章节或唯一学习顺序。每个 Goal 只激活一段相关子图；用户已有能力可以通过诊断证据确认，不要求从头走完整条路线。

## 6. Practice Model

Practice 是一个能对特定 Capability 产生可观察表现的任务。载体可以是口头解释、一道题、一段代码、实验、真实工作任务、小作品或完整项目。Project 是组合多个能力、成本和不确定性更高的高级 Practice，不是 Practice 的同义词。

```text
PracticeTask:
  task_id / version, target_capabilities, evidence_type,
  difficulty_band, prompt_or_artifact_contract,
  frozen_rubric, allowed_hint_policy, verification_method,
  context_distance (same / near / far / real-world)
Attempt:
  learner response/artifact reference, started_at, submitted_at,
  hint events, evaluation proposal, verified result
```

评分标准应在作答前固定或版本化，避免看过答案后临时改尺。技术任务优先用测试、运行结果等确定性检查；开放回答可用 rubric 评分，但 evaluator 的身份、置信/可信等级及抽样复核要能追溯。真实项目的完成也不自动证明项目涉及的全部能力。

## 7. Evidence Model

对外统一使用 Recall / Explain / Apply / Transfer 四种任务类型；内部可保留 `informational` 与 `performance` 分流。阅读、解释讲授、普通聊天、用户自评、用时和“已完成课程”可以作为上下文或学习日志，但不能单独作为 performance evidence。

```text
LearningEvidence {
  id, learner_id, capability_id, graph_version,
  session_id?, task_id?, task_version?, attempt_id?,
  type: recall | explain | apply | transfer,
  result: fail | partial | pass | transfer_pass,
  independence: independent | clarification | cue | scaffold | worked_step | solution,
  hint_events: [{kind, before_attempt?, decisive_step?}],
  difficulty_band, context_distance,
  rubric_version?, criterion_results?,
  evaluator: {kind, version?, trust_level}, evaluator_confidence?,
  observed_summary, artifact_ref?, occurred_at,
  validity: provisional | validated | rejected | superseded,
  source/provenance
}
```

只保留可审计的简短观察和必要 Artifact 引用，不保存隐藏推理链。每条证据必须可追溯到一个具体能力和任务版本；作答、提示事件、评分契约和结果需要关联，但应按隐私最小化保留。

### 7.1 L0–L4 作为“证据覆盖等级”，不是状态

| 等级 | 可说什么 | 最低证据含义 |
|---|---|---|
| L0 | 目前没有可用表现证据 | 未尝试或只有接触/自信/出席 |
| L1 Recall | 能少提示回忆关键事实/步骤 | 非选择认出、非照抄 |
| L2 Explain | 能用自己的话解释关系与边界 | 能给相关反例；非提示拼答案 |
| L3 Apply | 能独立完成代表性任务并核验 | 与讲解例题有实质差异，且关键步骤未被提示给出 |
| L4 Transfer | 能在明显不同情境迁移、说明取舍并处理例外 | 不是对原题换皮 |

L 等级描述“现有证据支持到哪”，不是学习者永久标签，也不直接等于 `stable`。例如最近一次 L4 transfer success 可以证明曾经迁移成功，但仍须查看时间、反证、任务/评分可信度，才能描述当前可靠程度。

### 7.2 Hint influence

强提示必须被记录，不能把提示后的成功算成独立应用/迁移。clarification 不必降级；cue/scaffold 可支持诊断或部分证据；worked-step/solution 后的正确结果只说明在支持下完成。Tutor 随后换一项表层特征或情境再验证，才可能获得较独立的新证据。

## 8. Mastery Model 与 Mastery Engine

### 8.1 正交表示

- `mastery_state`（unknown / learning / weak / stable）回答“当前学习状态如何”。
- `evidence_level`（L0–L4）回答“已展示的最高证据类型/水平”。
- `mastery_confidence` 回答“当前状态受证据支持的可靠程度”。

三者不能合成一个进度百分比。比如 `stable` 不代表已证明 transfer；`L4 evidence` 也不代表长期稳定。用户界面用自然语言和证据例子呈现，不展示虚假精确的小数。

### 8.2 State Machine first vs BKT

| 维度 | 确定性 Evidence State Machine | BKT |
|---|---|---|
| MVP复杂度 | 低；容易测试、追溯 | 中高；要定义技能粒度、项目参数和观测映射 |
| 可解释性 | 高；可以说出触发状态的证据规则 | 中；posterior 可算，但参数和单次观测需解释 |
| 泛学科 | 需按证据语义统一，Rubric 可适配开放学科 | 经典形式主要处理技能上的二元答对/错，开放作品信息会丢失 |
| 数据要求 | 少量证据可运作，但状态应保守 | 重复的 item-level 观察更有意义；P(T/G/S/L0) 需校准或谨慎先验 |
| AI 评分误差 | 可以标注 provisional、隔离低可信评估 | 错误二元化会直接影响概率，参数不会自动解决评估误差 |
| 扩展 | 以后可加入估计器接口，不必推倒 evidence ledger | 可提供概率估计，但不是独立掌握认证 |

**建议：MVP 使用确定性 State Machine + Evidence Ledger；BKT 作为未来 estimator 插槽，而非 MVP 决策中枢。** SkillCoco 的 BKT 是纯数学更新、将存储隔离在 trait 后；这对接口分离有借鉴价值，但它的成功/失败二元输入和项目默认阈值不能直接成为学程的通用学习真值。[实现源码](https://raw.githubusercontent.com/skillcoco/skillcoco/main/skillcoco-core/src/bkt.rs)。

```text
MasteryEstimator (interface)
  evaluate(capability_state, eligible_evidence, policy_version)
    -> state, evidence_level, confidence_band, reasons

MVP adapter: DeterministicEvidencePolicy
Future adapter: BKT / per-skill estimator (only after evidence quality & calibration study)
```

MVP 最小规则建议：没有有效表现证据为 `unknown`；已开始但证据不足为 `learning`；同一错误模式在多次有效表现中重复出现才是 `weak`；达到预先公布的多条、近期、低提示、不同任务/日期的正向表现门槛才可 `stable`。任何阈值先作为可版本化产品策略，并做反例测试，不包装成已验证的教育科学事实。一次失败不抹除历史；重复且可信的反证可以撤回当前稳定性或重开弱点。

## 9. Weakness / Misconception

Weakness 不是“答错一次”的标签。记录观察到的错误模式、可能原因（区分假设与事实）、关联 Evidence、诊断置信档、修复干预、关闭条件、首次/最近发生时间、复发次数和状态。需要用通过目标条件的新任务关闭；最近一次通过不一定自动抹去仍未验证的反复弱点。低置信诊断保持 suspected，不以确定语气呈现。

## 10. Study Session

一次 Session 只聚焦一个主要 Capability / Learning Intent：

```text
created → retrieve/diagnosis → teach/intervene → practice → verify → summary → completed
```

阶段可因熟悉度跳过讲解；安全、缺少先决知识或用户要快速参考时可跳过 retrieval。若进行了讲解，尽可能用一个变式任务验证。Session 中断需保存最小恢复锚点：目标能力、已确认状态、最后一次尝试/提示等级、未关闭弱点、待做验证、具体下一动作；恢复时先做短 retrieval，不从最后一条聊天文本盲目续讲。Session 的完成状态不升级 mastery。

## 11. Review Model

Review 是为记忆保持或重新验证而安排的活动，不是另一套掌握状态。第一版使用可解释、可调的日级区间/规则：失败或部分表现短间隔复测；通过后逐步延长；迁移表现可更长；优先处理逾期先修与开放弱点。初始区间仅是产品试行值，需按实际使用数据评估。

SkillCoco 的 SM-2 将 recall quality 与 repetitions/ease/interval 分开更新 review card；可借鉴“纯调度函数 + 持久化接口”。但 SM-2 的单卡记忆间隔不是 Capability mastery，更不能让一次 review failure 自动清空长期能力状态。未来可替换 FSRS/其他 scheduler，而不改 Evidence/Mastery 来源。[SkillCoco SM-2 实现](https://raw.githubusercontent.com/skillcoco/skillcoco/main/skillcoco-core/src/sm2.rs)。

## 12. Next Step Authority

### 单写入者

保持唯一 `NextStepEngine/Service` 写 official current Next Step。Planner、Memory、Goal、Schedule、Session、Review 只提交带 `source_type/source_id` 的 candidate。每人最多一个 `current`；被接受、开始、完成、替换均通过同一个状态机和事务完成。LLM 可以建议标题、理由或任务草稿，不决定用户是否掌握、日程是否正式、目标是否改变。

### 第一版候选排序

1. 已到期且重要的 Review / open weakness 验证；
2. Goal 相关且 prerequisites 满足的 `weak` Capability；
3. 最近中断、仍值得继续的 session/action；
4. 用户确认的临近 Schedule（同时满足可用时间）；
5. 活跃 Goal 下准备好的正常下一能力；
6. 缺乏证据时给出低置信的诊断/澄清建议，不伪装成正式学习安排。

候选依次考虑 goal priority、先修可达性、影响/风险、证据时效与强度、预计时长匹配、用户明确偏好、最近重复/多样性、recency。硬约束先过滤，再用版本化确定性排序；平分按稳定 tie-break。系统必须记录选择所用信号和规则版本，可回答“为什么推荐”。用户可开始、稍后、改时间、跳过或换一个；不通过隐式 AI 重新排序覆盖用户的明确选择。

## 13. AI Companion Responsibility

AI 可以澄清目标、生成或解释候选路线、诊断问题假设、教学、出题、按 rubric 给评分提议、整理 Daily Log 草稿、建议 Memory / Schedule / Next Step。它不能未经确认改 Goal、持久写 Memory、确认 Schedule、写 Skill State、把聊天当证据或覆盖 official Next Step。

会话教学原则：先以小问题看用户怎么想；按需逐级增加提示；不重复同一提示；干预后换一个有意义的任务特征再核验。直接回答设备/设置等非学习目标问题，或用户主动选择快速答案时，不强迫苏格拉底流程。用户挫败、赶时间、无障碍需求或任务风险时应降低摩擦；productive struggle 不是拒绝帮助。

对生成任务和 AI 评分必须显式记录其可信边界：Rubric 评分 ≠ 内容事实已证；运行测试可以检查特定行为但不代表完整能力；高风险专业领域不发出强 mastery 结论，必要时需真实可信的人类评审来源。

## 14. Memory / Daily Log 与学习状态边界

| 对象 | 示例 | 能否影响 Skill State |
|---|---|---|
| Memory / Learner Preference | “我未来想做 AI 产品”“偏好晚上短时学习” | 否；仅帮助上下文与个性化 |
| Direction / Goal | “在三个月内能独立发布一个 AI 原型” | 否；定义目标优先级和路线约束 |
| Daily Log | “今天学习递归时做了三题” | 否；用户确认的回顾，不代替结构化作答 |
| Conversation | 用户提问、Tutor 解释、确认记忆 | 否；需要另行产生一个可评估 Practice Attempt |
| Learning Evidence | 在冻结任务上独立实现递归终止条件并通过测试 | 是；由 Evidence Aggregator 消费 |
| Schedule | 周三 19:00 复习 | 否；表示时间承诺，不表示学习成果 |

AI 对话内容可以成为 Memory proposal 或 Daily Log draft；长期事实须用户确认。真正作答可来自对话界面，但必须有明确 Practice Task、能力绑定、尝试边界和评估记录，才提交 Evidence。

## 15. UI Information Architecture（仅信息架构）

建议主导航探索为：

- **Today**：当前唯一 Next Step、为什么、预计时长、最近一条正式安排、逾期 review/恢复 session 的最高优先级项。回答“现在做什么”。
- **Path**：Direction/Goal、相关 Capability 子图、先修和当前 Evidence/State。回答“为什么是这一步、我走到哪”。图是可操作路线，节点能打开证据和可执行练习，不只是装饰。
- **Companion**：自然对话、解释、目标/Memory/日程/任务建议的 inline confirmation。聊天不会作为 mastery 记录。
- **Me**：学习者自述与偏好、已确认 Memory、成长日志及隐私/设置。区分“我告诉小程的”与“练习中观察到的”。

Study Session 是从 Today/Path/Companion 发起的聚焦工作流，完成后以 Result 显示本次表现、下一步和复习候选，再返回 Today；不必成为永久主 Tab。Schedule 可从 Today 进入日程详情/安排管理；只要用户日历管理是高频独立任务，再考虑将其设为一级导航，避免与 Today 争抢首要任务。`Daily Log` 在 Session Result 内低成本起草、确认，而不是额外要求每日填表。

状态必须显露：`unknown` 不伪装进度；`weak` 用自然语言与具体例子；`stable` 显示最近支撑它的表现和复习状态；AI suggestion 与 user-confirmed state 视觉语义分开；Session 中断有原地恢复入口；Result 区分“练习完成”与“能力证据”。

## 16. Open-source Inspirations（研究摘要）

### 16.1 MasteryThread

**定位 / 模型：** portable、evidence-first 的学习项目与 AI Coach；通过 retrieve → observe → intervene → verify → record → schedule 推进，学习 State 可版本化导入/导出。

**数据与状态：** project、learner、roadmap/units、mastery、weaknesses、evidence、reviews、sessions、sources、resume。Evidence 有能力、类型、结果、提示级别、简短观察、支持等级、验证方式、时间及可选 artifact；weakness 连接证据、可能原因、置信、干预和关闭条件；resume 保存精确 next action。

**Mastery / hints / review：** L0–L4 从无表现到 Recall、Explain、Apply、Transfer；L3/L4 需低提示独立表现，修正讲解后要再测变式。提示等级区分 clarification/cue/scaffold/worked-step/solution；强提示不能支撑高阶独立能力。复习从真实 `fail/partial/pass/transfer` 结果排期，优先逾期先修和未关闭弱点；失败不删除过去记录。恢复从已验证能力、弱点、到期复习和 next action 开始，而不是恢复到最后打开的页面。

**Tutor / Practice / 路径：** 要求简短诊断、具体能力、前置、接受证据、真实/近真实任务；每次只处理一个主要目标，retrieve 后采取最小有效干预，并换变式核验。聊天、时间和自信不是掌握证明。

**适合学程：** evidence ledger、hint accounting、weakness closure condition、interrupt-resume anchor、schema version 与未知字段保留。**不适合照搬：** 按项目文件维护状态不等于适合所有用户的产品数据架构；L0–L4 是证据量规，不能成为单一 Skill State 或全局分数；具体区间需要本产品评测。**许可证：** 仓库 MIT；若复用软件仍保留版权与许可证声明；本轮不复制实现。[README](https://github.com/heyard2026/mastery-thread) · [Skill flow](https://raw.githubusercontent.com/heyard2026/mastery-thread/main/skill/mastery-thread/SKILL.md) · [State contract](https://raw.githubusercontent.com/heyard2026/mastery-thread/main/skill/mastery-thread/references/state-contract.md) · [Rubric](https://raw.githubusercontent.com/heyard2026/mastery-thread/main/skill/mastery-thread/references/mastery-rubric.md) · [Review scheduler](https://raw.githubusercontent.com/heyard2026/mastery-thread/main/skill/mastery-thread/scripts/review_scheduler.py)

### 16.2 SkillCoco

**定位 / 模型：** 可离线运行的自适应桌面学习应用，以模块化内容、练习、测验、Terminal Lab 和自带模型密钥 Tutor 组织学习。

**数据 / 循环：** BKT 的核心为每个 learner × module 保存知识概率；每次正确/错误观察由四个参数更新 posterior，另有纯算法与存储接口边界。练习和 Lab 将作答送入确定性检查，开放文本才可进入 rubric AI fallback；检查失败时不静默通过。SM-2 对每张复习卡记录 repetitions/ease/interval/next due，按 review quality 改变间隔。

**适合学程：** 算法纯函数化、存储接口独立；练习检查优先确定性，AI judge 作为受限回退且清楚表达不确定；复习调度与 mastery 分离。**不适合照搬：** 二元答错/答对无法代表开放解释、实践作品和迁移；默认参数/0.7 门槛是项目设置，非跨学科通用阈值；SM-2 card interval 不能等于能力掌握；带积分/徽章/连续使用压力的设计可能与长期 calm companion 冲突。**许可证：** 仓库及 `skillcoco-core` MIT；保留声明；任务要求重点源码已审阅。[README](https://github.com/skillcoco/skillcoco) · [BKT implementation](https://raw.githubusercontent.com/skillcoco/skillcoco/main/skillcoco-core/src/bkt.rs) · [SM-2 implementation](https://raw.githubusercontent.com/skillcoco/skillcoco/main/skillcoco-core/src/sm2.rs)

### 16.3 Tutor MCP

**定位 / 模型：** 给 AI 客户端提供的持久学习引擎；把生成式教学内容与确定性学习状态/路径控制分开。Structured learning state 与 narrative memory 分层；前者存版本化概念图、目标、互动、mastery estimate、review、assessment/transfer；后者保存稳定笔记、待确认观察、session 摘要等。

**路径与循环：** 目标映射到能力图；KST-inspired prerequisites 校验图和可达性；phase controller、candidate gates、概念选择、动作选择后留下 decision contract；生成任务先冻结 task/rubric，再收作答和评估。BKT estimate、retention、demonstration 和 transfer 分开；near/far/debugging/teaching/creative transfer probe 不应仅凭估计分数通过。

**Tutor / Practice / Review：** LLM 负责解释、任务、反馈、总结，运行时负责证据政策、前置门槛、调度和审计。Practice 有诊断、练习、recall、误解处理、explanation、mastery challenge 与 transfer；FSRS 用于复习而不是 mastery；决策能检查为什么选择/拦截。

**适合学程：** Graph version + decision reason、先修过滤先于排序、task/rubric 冻结、生成式 Tutor 与状态写入分离、assessment trust 层级。**不适合照搬：** 整套 MCP、多租户/管理员/认证/worker 架构超出学程本阶段；BKT+FSRS+复杂 regulation 对数据和校准要求高；仓库自己的文档明确承认算法是可审计路由启发式而非心理计量验证。**许可证：** MIT；本轮仅采用抽象设计思想。[Architecture](https://github.com/ArnaudGuiovanna/tutor-mcp/blob/main/docs/architecture.md) · [Algorithms](https://github.com/ArnaudGuiovanna/tutor-mcp/blob/main/docs/algorithms.md) · [Learning integrity](https://github.com/ArnaudGuiovanna/tutor-mcp/blob/main/docs/learning-integrity.md)

### 16.4 Upstack

**定位 / 模型：** 通过可加载导师协议和技能文档配置 AI 开发学习；强调 Guide 和 Scribe 不同时运行、先作答再逐级提示、保存错误/修正/顿悟，而非只保存最终产物。

**路径 / Tutor / Practice：** 学习者档案用于校准语言和挑战；课程/learning path 与真实项目连接，逐步把组件合并为项目；productive struggle 的摩擦需要可调，而不是拒绝帮助。Journal 记录思路、错误、修正和 aha moments，并帮助跨 session 延续。

**适合学程：** 记录“怎么改变想法”的精选反思；Attempt 前不给关键答案；提示逐级且不重复；真实项目作为高阶实践；Tutor 要允许直接回答非学习目标问题、无障碍/时间需求和用户控制。**不适合照搬：** 强制所有提问都 Socratic、把 Git 仓库提交流程当学习产品核心、要求完整记录错误全过程或把项目完结当唯一成功会增加摩擦和隐私负担；Dreyfus 分类不能直接等同于每项 Capability 的掌握状态。**许可证风险：** 明确双许可：代码（如 `scripts/`、`*.js` 等所界定代码）MIT；课程、skills、导师协议、原则、文档及其他非代码内容 CC-BY-SA 4.0。产品实现应只借鉴通用想法，不复制它的课程材料、Agent 指令、Journal 模板或文案；若未来必须复用内容，先核实归属、署名和 ShareAlike 对衍生内容的义务。[Guide](https://github.com/ishands/upstack/blob/main/docs/LEARNING-WITH-UPSTACK.md) · [Tutor contract](https://github.com/ishands/upstack/blob/main/AGENTS.md) · [License](https://github.com/ishands/upstack/blob/main/LICENSE)

### 16.5 s0crate / Socrate

**定位 / 模型：** 本地优先 AI 学习工作台；通过苏格拉底式 onboarding 澄清背景和目标，生成可导航的 syllabus，围绕知识点会话，并将过程保存为 Markdown/JSON。

**数据 / 循环：** session metadata、syllabus、topic notes、session log、summary；用户先澄清目标，再生成树状大纲，逐节点学习，可以切换/返回/总结，保留局部对话上下文与全局学习位置。Practice 主要体现为解释、例子、逐主题深挖，README/PRD 尚不能证明存在严格的 performance evidence/mastery 算法或适应性 review scheduler。

**适合学程：** 少量高价值澄清问题、节点上下文、恢复位置与用户可导出的学习产物。**不适合照搬：** 把 AI 生成的 syllabus 当能力图真值、以 topic 完成度作为能力证据、长时间保存完整模型对话；多文件 Markdown 是该桌面产品选择，并非学程跨端账户/同步必需。**许可证：** README 声明 MIT；如要重用实际代码仍需检查单文件声明、依赖许可证及版权声明。[PRD](https://raw.githubusercontent.com/spaxfiz/s0crate/main/docs/PRD.md) · [README/API/data format](https://github.com/spaxfiz/s0crate)

## 17. V1 → V2 的变化

| V1 概念 | V2 处理 | 原因 |
|---|---|---|
| Goal | 保留；明确 Direction 与可确认 Goal 的层级，Goal 可链接多个 Capability | 长期方向不一定是单一里程碑；独立生命周期保留 |
| Skill | 精化为版本化 Capability Definition + Learner Capability State | 章节/技能名可能是内容单元，不一定是可观察能力 |
| Learning Evidence | 强化为带任务版本、提示、独立性、难度、评估来源/可信度的 append-only 记录 | 解决聊天/解释/自评误升 mastery |
| Skill State | 与 L0–L4 Evidence Level 解耦；MVP 确定性 aggregator 单写 | 避免一个枚举同时代表能力、证据和置信度 |
| Study Session | 保留为一次执行容器，明确可中断/恢复，不直接写掌握 | 完成学习活动不等于掌握 |
| Next Step | 保留唯一 authoritative engine；接入 Capability DAG、review、availability | 多源只能出候选，不互相覆盖 |
| Memory | 保持伙伴上下文，与 Direction/Goal/Evidence 分开 | 记忆个人事实不等于正式目标或技能事实 |
| Schedule | 保持用户确认才是正式安排 | 日期承诺不等于学习结果；建议仍 pending |
| Daily Log | 作为用户确认的叙事反思；可引用 Evidence 但不替代它 | 避免日记活动描述自动当能力证明 |

**新增概念及理由：** `Direction` 用于较宽、长期的成长方向；`Capability` 用于目标与可观察表现间的桥；`GoalCapabilityLink` 表示目标相关性，不把所有能力都塞进每个目标；`PracticeTask/Attempt` 让证据有明确任务上下文；`Weakness` 表示有关闭条件的反复困难；`Review` 管保持而非掌握；`graph_version/policy_version` 解释历史判断为何产生；`evaluator trust` 防止把模型置信度当评分可靠性。

## 18. MVP Boundary

### 建议纳入

1. 单一 Goal 下由人工审核/用户确认的小型 Capability DAG（先覆盖一个窄领域）；
2. Goal ↔ Capability link 和 graph version；
3. Recall / Explain / Apply 三类明确任务，Transfer 先做少量人工/结构化设计；
4. 不可变 Evidence + hint event + 任务/rubric 版本 + evaluator provenance；
5. 确定性状态规则：unknown/learning/weak/stable 与 L0–L4 分开；
6. 单一 NextStepEngine，从 review、weak prerequisite、Goal、未完成 session、正式 schedule 产生并解释一个 current action；
7. 复习先用朴素、可解释的日级政策；Review 更新不直接覆写 mastery；
8. 基础恢复锚点和真实用户可控项（继续、稍后、调整、暂停）。

### 明确暂缓

通用自动生成并直接发布整张 Capability Graph、在线 BKT 个体参数拟合、FSRS 全量调度、向量记忆/知识图谱、跨域迁移自动认证、排行榜/连续打卡激励、多 Agent 自动执行、未经用户确认的提醒/计划变更、成绩或就业等高风险 mastery 声明。

## 19. Open-source inspirations / License notes

| 项目 | 可借鉴的机制 | 许可与边界 |
|---|---|---|
| MasteryThread | evidence rubric、hint accounting、弱点闭环、resume | MIT；不复制其源代码和状态契约 |
| SkillCoco | BKT/SM-2 纯函数与存储分离、确定性练习检查 | MIT；不复制源实现，先验证学程的输入假设 |
| Tutor MCP | 图版本、先修 DAG、评估契约、可解释选路 | MIT；不引入整个服务或过度复杂算法 |
| Upstack | productive struggle、渐进提示、journal | 代码 MIT；skills/课程/导师文档等 CC-BY-SA 4.0，避免复制非代码内容 |
| s0crate | 目标澄清、节点上下文、耐久摘要/恢复 | MIT；避免复制其内容或将生成 syllabus 当真值 |

许可证概览不是法律意见。未来若确需代码/文本复用，应核对锁定 commit、具体文件的许可证、依赖与通知义务；Upstack 内容的再利用尤其需要单独评估 CC-BY-SA 的署名与相同方式共享要求。

## 20. Future Extensions / 开放问题

- 当累计多少、何种质量的 item-level 观测后，才值得试验 BKT？需离线回放与独立评测，而不是因为能计算概率就上线。
- 哪些能力状态和解释对成人自学者确有帮助？用户是否理解“证据等级”与“掌握状态”的区别？
- 开放回答 rubric 如何校准？模型评估偏差如何抽样复核、如何让用户申诉？
- Capability 图由专家、AI、用户或三者怎样共同维护？如何避免先修错误将用户锁在路线里？
- Review 失败应该先复测、重新教学还是重开 weakness？需按学科和任务危险性设计策略。
- 多 Goal 冲突与可用时间不足时如何尊重用户优先级；Next Step 是否支持用户手动 pin？
- 如何在隐私、长期记忆、对话删除与 Evidence 审计之间做可解释的保留/删除策略？

## 21. 下一阶段建议（非本阶段实现）

先对接当前正式后端/API 的实际代码与数据库，而非历史计划，做一张“现状实体/写入者 → V2 概念”只读映射。随后只选择一个窄学习领域，用固定 task/rubric 和合成反例集，验证 Evidence→Skill State→Next Step 的确定性规则；先定义迁移/兼容与用户可见解释，再讨论最小 API/存储调整。BKT、全图生成、界面扩展都排在该规则通过离线评测之后。

## 研究来源与范围说明

研究基于 2026-09-28 可访问的公开 GitHub 源码与项目文档；仓库内容是作者实现和设计主张，不代表独立教育效果验证。核心源码包括 SkillCoco 的 `bkt.rs`、`sm2.rs`；MasteryThread 的 State Contract、Mastery Rubric、review scheduler；Tutor MCP 的 Architecture、Algorithms、Learning Integrity；Upstack 的 Tutor Contract、Learning Guide 和 License；s0crate 的 PRD 与数据/路由说明。本文只概念综合，不复制任何第三方实现或长段文本。

